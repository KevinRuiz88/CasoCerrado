
package Modelo;

public class Cibercrimen extends Caso{
    
    private String tipoCrimen;

    public Cibercrimen(){this.tipoCrimen="";}
    public String getTipoCrimen() {return this.tipoCrimen;}
    public void setTipoCrimen(String tipoCrimen) {this.tipoCrimen = tipoCrimen;}
}
