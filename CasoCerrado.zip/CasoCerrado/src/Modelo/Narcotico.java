package Modelo;

public class Narcotico extends Caso {
    
    private String sede;

    public Narcotico(){
        this.sede = "";
    }

    public String getSede() {return sede;}
    public void setSede(String sede) {this.sede = sede;}
}
